﻿namespace Cake.Common.Tools.XBuild
{
    internal enum XBuildVersion
    {
        XBuild20 = 1,
        XBuild35 = 2,
        XBuild45 = 3
    }
}