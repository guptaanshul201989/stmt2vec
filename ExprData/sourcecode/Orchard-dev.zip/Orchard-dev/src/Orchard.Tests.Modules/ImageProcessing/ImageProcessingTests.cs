﻿using System.Reflection;
using Moq;
using NUnit.Framework;
using Orchard.MediaProcessing.Services;

namespace Orchard.Tests.Modules.ImageProcessing {
    [TestFixture]
    public class ImageProcessingTests {

        
    }
}
