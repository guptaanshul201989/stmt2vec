﻿using Orchard.ContentManagement;
using Orchard.Tests.ContentManagement.Records;

namespace Orchard.Tests.ContentManagement.Models {
    public class DeltaPart : ContentPart<DeltaRecord> {
    }
}
