﻿using Orchard.ContentManagement;
using Orchard.Tests.ContentManagement.Records;

namespace Orchard.Tests.ContentManagement.Models {
    public class GammaPart : ContentPart<GammaRecord> {
    }
}
