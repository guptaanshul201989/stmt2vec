﻿namespace Orchard.Tests.Environment.TestDependencies {

    public interface IAlphaDependency : IDependency {
    }

    public class AlphaDependency : IAlphaDependency {
    }
}
