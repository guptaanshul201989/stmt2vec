namespace Primes
{
    public interface IPrimeGenerator
    {
        string GeneratePrimesUpTo(int max);
    }

}