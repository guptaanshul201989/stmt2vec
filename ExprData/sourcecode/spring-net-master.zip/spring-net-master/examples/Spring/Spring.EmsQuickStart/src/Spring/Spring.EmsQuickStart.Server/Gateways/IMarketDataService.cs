namespace Spring.EmsQuickStart.Server.Gateways
{
    public interface IMarketDataService
    {
        void SendMarketData();
    }
}