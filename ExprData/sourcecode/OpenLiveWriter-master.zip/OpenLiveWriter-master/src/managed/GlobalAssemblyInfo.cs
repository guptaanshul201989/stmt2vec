using System.Reflection;

// Product and file versions are auto-generated from version.txt

[assembly: AssemblyProduct("Open Live Writer")]
[assembly: AssemblyCompany("Open Live Writer")]
[assembly: AssemblyCopyright("Copyright (c) .NET Foundation. All rights reserved.")]
[assembly: AssemblyTrademark("")]
