﻿Important info:

Build Writer first. 
Then you can build and add code to this Isolated Canvas. 

You can change what binaries you bind to via TestCanvas.exe.config. There are helpful comments there. 

Making the changes in the config file will allow you to easily switch between 'installed buddy build' and 'bbpack buddy build' binaries. 



More info contact: Unknown