﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.WindowsAzure.Management.HDInsight.Contracts.March2013
{
    public enum SqlMetastoreType
    {
        HiveMetastore,
        OozieMetastore
    }
}
