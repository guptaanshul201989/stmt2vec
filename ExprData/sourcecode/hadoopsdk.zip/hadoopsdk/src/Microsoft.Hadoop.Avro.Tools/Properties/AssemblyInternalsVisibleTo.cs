﻿// /********************************************************
// *                                                       *
// *   Copyright (C) Microsoft. All rights reserved.       *
// *                                                       *
// ********************************************************/

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Microsoft.Hadoop.Avro.Tests")]
