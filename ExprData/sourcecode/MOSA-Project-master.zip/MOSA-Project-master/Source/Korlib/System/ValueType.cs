﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace System
{
	/// <summary>
	///
	/// </summary>
	public class ValueType : Object
	{
		public override string ToString()
		{
			return GetType().ToString();
		}
	}
}
