﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace System
{
	/// <summary>
	/// Implementation of the "System.ParamArrayAttribute" class.
	/// /// </summary>
	public class ParamArrayAttribute : Attribute
	{
	}
}
