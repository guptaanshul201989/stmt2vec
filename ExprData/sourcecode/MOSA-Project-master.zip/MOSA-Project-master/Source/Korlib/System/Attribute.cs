﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace System
{
	/// <summary>
	/// Implementation of the "System.Attribute" class.
	/// </summary>
	public class Attribute
	{
	}
}
