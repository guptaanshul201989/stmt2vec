// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace Mosa.Compiler.Common
{
	public enum Endianness { Little, Big };
}
